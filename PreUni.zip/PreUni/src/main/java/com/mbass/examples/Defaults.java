package com.mbass.examples;

public class Defaults
{
  
public static final String APPLICATION_ID = "205F705B-A776-9CD0-FF4C-91926D881700";
public static final String API_KEY = "98107905-945A-F5BD-FFE5-B14F2B0B0200";
public static final String SERVER_URL = "https://api.backendless.com";
    
}
                                            